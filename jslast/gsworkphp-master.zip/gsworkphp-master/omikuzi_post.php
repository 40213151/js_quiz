<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/omikuzi_post.css">
    <link rel="stylesheet" href="css/reset.css">
</head>
<body>
  
<div id="sitetitle">
   <div id="sitetitle2">
    <h1>本を登録するマン</h1>
    <h2>キミの好きな本を登録するマン！</h2>
    </div>
</div>
      
      
<div id="text">
<form method="post"action="insert.php">
    
    <ul id="form-list">
        <dl id="form-item">
            <dt for="namae" class="form-label">名前</dt>
            <dd class="form-detail">
                <input type="text" name="name" class="form-parts">
            </dd>
        </dl>
        
        <dl id="form-item">
            <dt for="add" class="form-label">URL</dt>
            <dd class="form-detail">
                <input type="text"name="url"class="form-parts">
            </dd>
        </dl>
        
        <dl id="form-item">
            <dt for="iki" class="form-label">おすすめポイント</dt>
            <dd class="form-detail">
                <input type="text" name="coment" class="form-parts2">
            </dd>
        </dl>
    </ul>
        
<p id="t"><input type="submit" value="送信" class="submit"></p>

</form>
</div>
       <a href="select.php">履歴</a>
<div id="footer">
<p>copyrights 2016 G's Academy Tokyo All RIghts Reserved.</p></div>

</body>
</html>