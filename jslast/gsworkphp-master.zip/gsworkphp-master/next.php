

<?php
$num=rand(1,3);

if($num==1){
    include("good.php");
}else if($num==2){
    include("nomal.php");
}else if($num==3){
    include("bad.php");
}
?>