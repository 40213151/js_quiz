<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/omikuzi_post2.css">
    <link rel="stylesheet" href="css/reset.css">

</head>
<body>
    
      
<div id="sitetitle">
   <div id="sitetitle2">
    <h1>今日の運勢占うマン</h1>
    <h2>本を登録すると見せかけて 実は占いマン！</h2>
    </div>
</div>
      
<div id="kekka">
    <h1 id="k">( ｀ー´)ノまあまあだね(*´ω｀*)</h1>
      <p id="sub">あなたの運勢
      はふつうです 無難に生きてください</p>
</div>
      
<a href="omikuzi_post.php">もどる</a>
<a href="select.php">履歴</a>
      <div id="footer">
<p>copyrights 2016 G's Academy Tokyo All RIghts Reserved.</p></div>

</body>
</html>